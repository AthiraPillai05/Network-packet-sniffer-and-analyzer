# gui.py
import tkinter as tk
from tkinter import ttk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from analyzer import packet_count, ALERT_THRESHOLD
import threading
import time

class SnifferGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Network Packet Sniffer GUI")

        # Frame for controls
        self.control_frame = ttk.Frame(root)
        self.control_frame.pack(side=tk.TOP, fill=tk.X)

        self.start_btn = ttk.Button(self.control_frame, text="Start Sniffer", command=self.start_sniffer)
        self.start_btn.pack(side=tk.LEFT, padx=5, pady=5)

        self.stop_btn = ttk.Button(self.control_frame, text="Stop Sniffer", command=self.stop_sniffer)
        self.stop_btn.pack(side=tk.LEFT, padx=5, pady=5)

        # Matplotlib figure
        self.fig, self.ax = plt.subplots(figsize=(8,5))
        self.ax.set_title("Packets per IP")
        self.ax.set_xlabel("IP Address")
        self.ax.set_ylabel("Packet Count")
        self.bar_container = None

        # Embed figure in Tkinter
        self.canvas = FigureCanvasTkAgg(self.fig, master=root)
        self.canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        # Animation
        self.ani = animation.FuncAnimation(self.fig, self.update_graph, interval=1000)

        # Sniffer thread flag
        self.sniffer_thread = None
        self.running = False

    def start_sniffer(self):
        from sniffer import start_sniffer
        if not self.running:
            self.running = True
            self.sniffer_thread = threading.Thread(target=start_sniffer, daemon=True)
            self.sniffer_thread.start()

    def stop_sniffer(self):
        self.running = False
        # Currently scapy sniff runs indefinitely, stopping requires CTRL+C or redesign with stop_filter.

    def update_graph(self, i):
        ips = list(packet_count.keys())
        counts = [packet_count[ip] for ip in ips]
        colors = ['red' if packet_count[ip] > ALERT_THRESHOLD else 'blue' for ip in ips]

        self.ax.clear()
        self.ax.bar(ips, counts, color=colors)
        self.ax.set_title("Packets per IP")
        self.ax.set_xlabel("IP Address")
        self.ax.set_ylabel("Packet Count")
        self.ax.tick_params(axis='x', rotation=45)
        self.fig.tight_layout()
