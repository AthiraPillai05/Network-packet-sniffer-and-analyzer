# main.py
from db import init_db
from analyzer import start_reset_thread
from sniffer import start_sniffer
import threading

def main():
    print("Initializing database...")
    init_db()

    print("Starting analyzer...")
    start_reset_thread()

    print("Starting packet sniffer...")
    t = threading.Thread(target=start_sniffer)
    t.start()
    t.join()  # Keep main thread running

if __name__ == "__main__":
    main()
