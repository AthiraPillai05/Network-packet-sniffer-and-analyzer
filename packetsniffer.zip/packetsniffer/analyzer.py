# analyzer.py
from alert import send_alert
from collections import defaultdict
import time
import threading

packet_count = defaultdict(int)
ALERT_THRESHOLD = 10   # packets from same IP in interval
INTERVAL = 5           # seconds

def check_anomalies(packet_info):
    src_ip = packet_info["src_ip"]
    packet_count[src_ip] += 1
    if packet_count[src_ip] > ALERT_THRESHOLD:
        send_alert(f"High traffic detected from {src_ip}: {packet_count[src_ip]} packets")
        packet_count[src_ip] = 0

def reset_counters():
    """Reset packet count periodically"""
    global packet_count
    while True:
        time.sleep(INTERVAL)
        packet_count = defaultdict(int)

def start_reset_thread():
    """Start background thread to reset counters"""
    t = threading.Thread(target=reset_counters, daemon=True)
    t.start()
