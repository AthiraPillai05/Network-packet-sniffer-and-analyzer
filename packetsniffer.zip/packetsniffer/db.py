# db.py
import sqlite3

DB_FILE = "packets.db"

def init_db():
    """Create SQLite table if it doesn't exist"""
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS packets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            src_ip TEXT,
            dst_ip TEXT,
            src_port INTEGER,
            dst_port INTEGER,
            proto TEXT,
            length INTEGER,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

def log_packet(packet_info):
    """Insert captured packet into database"""
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("""
        INSERT INTO packets (src_ip, dst_ip, src_port, dst_port, proto, length)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        packet_info.get("src_ip"),
        packet_info.get("dst_ip"),
        packet_info.get("src_port"),
        packet_info.get("dst_port"),
        packet_info.get("proto"),
        packet_info.get("length")
    ))
    conn.commit()
    conn.close()
