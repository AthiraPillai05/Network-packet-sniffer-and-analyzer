# sniffer.py
from scapy.all import sniff, IP, TCP, UDP
from db import log_packet
from analyzer import check_anomalies

def packet_handler(packet):
    if IP in packet:
        info = {
            "src_ip": packet[IP].src,
            "dst_ip": packet[IP].dst,
            "length": packet[IP].len,
            "src_port": packet[TCP].sport if TCP in packet else (packet[UDP].sport if UDP in packet else None),
            "dst_port": packet[TCP].dport if TCP in packet else (packet[UDP].dport if UDP in packet else None),
            "proto": "TCP" if TCP in packet else "UDP" if UDP in packet else str(packet[IP].proto)
        }
        log_packet(info)        # Save to database
        check_anomalies(info)   # Check for high traffic

def start_sniffer():
    sniff(prn=packet_handler, store=False)
