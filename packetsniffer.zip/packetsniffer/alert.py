# alert.py
def send_alert(message):
    """
    Trigger an alert.
    Prints message to console and logs to alerts.log
    """
    print(f"[ALERT] {message}")
    with open("alerts.log", "a") as f:
        f.write(f"{message}\n")
